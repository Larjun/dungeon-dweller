#include <iostream>
#include <fstream>
#include <string>
#include "Player.h"
#include "Attack.h"
#include "Enemy.h"
#include "Inventory.h"

using namespace std;

//combat function
/* will take the player and the integer of the randomized enem y and will perform the combat function
where a loop will take place until either the hp of the enemy or the player becomes 0.

The player will be asked user inputs for that moves he can do
*/

/* several menu functions will be placed to make coding easier*/
    //map menu function -
        /*  1.move up
            2.move down
            3.move left
            4.move right
            5.use item - will bring up the inventory menu function
            6.scan level (counts the number of enemies alive in the level)
            7.move up a level (if in highest level accessible, returns you are in the highest accessible level)
            8.move down a level (if in lowest level accessible, returns you are in the highest accessible level)
        */

    //combat menu function - will be shown in combat with player hp, mp and ap and enemy hp
        /*  1.use slash
            2.use pierce
            3.use elemental magic
            4.use pure magic
            5.use item - will bring up the inventory menu function
            6.standby
            */
    
    //inventory menu function
        /*  1.use health potion - playerinventory.gethealthpotion()
            2.use mana potion - playerinventory.getmanapotion()
            3.repair armor - playerinventory.getscrapmetal()
            
            number of keys will be shown
        */


/*funtion to form the enemy list will be read and an array will be filled with enemy objects to be called at will. It will be read from a file*/

/*funtion to load the maps and write new ones to help move down level*/

int main(){
    
    ////////////////////the game will be intialised///////////////////////////
    //maps will be loaded in
    //maps will be loaded in with the variable
    
    //files to read
    /*  5 maps
        attack file
        enemy file
    */

    //all objects will be made and all files will be read
    //player will input the name and start the game

    //the game will be played below.
    ////////////////////game play///////////////////////////
    //if the player gains a key, he will be able to move up a level and the level he left will be updated as a new file
        //max levels access - 1 == playerinventory.getkeys()
        
    //if the player lands in the square of an enemy, the combat function will take place
    //if the player dies, he will receive the prompt "You died! Game Over!"
    //if the player receives all 5 keys the game will end saying "You left the dungeon"
}
