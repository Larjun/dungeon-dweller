#include <iostream>
#include "Inventory.h"

using namespace std;

Inventory::Inventory(){
    healthPotions = 0;
    manaPotions = 0;
    scrapMetals = 0;
    int keys = 0;
}
Inventory::Inventory(int h_potions, int m_potions, int metals){
    healthPotions = h_potions;
    manaPotions = m_potions;
    scrapMetals = metals;
    keys = 0;
}
        
//health potions
int Inventory::getHealthPotions(){
    return healthPotions;
}
void Inventory::addHealthPotions(){
    healthPotions = healthPotions + 1;
}

//mana potions
int Inventory::getManaPotions(){
    return manaPotions;
}
void Inventory::addManaPotions(){
    manaPotions = manaPotions + 1;
}

//scrap metals
int Inventory::getMetals(){
    return scrapMetals;
}
void Inventory::addMetals(){
    scrapMetals = scrapMetals + 1;
}

//keys
int Inventory::getKeys(){
    return keys;
}
void Inventory::addKeys(){
    keys = keys + 1;
}