#include <iostream>
#include "Attack.h"

using namespace std;

Attack::Attack(){
    atkName = "";
    baseDmg = 0;
    dmgInc = 0;
    manaCost = 0;   
}
Attack::Attack(string name, int dmg, string type, double inc, int mCost){
    atkName = name;
    baseDmg = dmg;
    dmgInc = inc;
    manaCost = mCost;
    if (type == "Physical"){
        atkType = true;
    }
    else if (type == "Magic"){
        atkType = false;
    }
}

//attack name
void Attack::setAtkName(string name){
    atkName = name;
}
string Attack::getAtkName(){
    return atkName;
}

//base damage
void Attack::setBaseDmg(int dmg){
    baseDmg = dmg;
}
int Attack::getBaseDmg(){
    return baseDmg;
}

//attack type
void Attack::setAtkType(string type){
    if (type == "Physical"){
        atkType = true;
    }
    else if (type == "Magic"){
        atkType = false;
    }
}
bool Attack::getAtkType(){
    return atkType;
}

//damage increment per usage of move. the new base damage will still be an int
void Attack::setDmgInc(double inc){
    dmgInc = inc;
}
double Attack::getDmgInc(){
    return dmgInc;
}

//mana cost
void Attack::setManaCost(int mCost){
    manaCost = mCost;
}
int Attack::getManaCost(){
    return manaCost;
}