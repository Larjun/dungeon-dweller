#ifndef INVENTORY_H
#define INVENTORY_H
#include <iostream>
using namespace std;
class Inventory{
    private:
        int healthPotions;
        int manaPotions;
        int scrapMetals;
        int keys;
    
    public:
        Inventory();
        Inventory(int h_potions, int m_potions, int metals);
        
        //health potions
        int getHealthPotions();
        void addHealthPotions();

        //mana potions
        int getManaPotions();
        void addManaPotions();

        //scrap metals
        int getMetals();
        void addMetals();

        //keys
        int getKeys();
        void addKeys();

        //all adds are either +1 or -1 

};

#endif