#include <iostream>
#include <fstream>
#include <string>
#include "Player.h"
#include "Attack.h"

using namespace std;
Player::Player(){
    plname = "";
    hp = 0;
    mp = 0;
    ap = 0;
}
Player::Player(string newName, int newHealth, int newMana, int newArmor){
    plname = newName;
    hp = newHealth;
    mp = newMana;
    ap = newArmor;
}
        
//health functions
int Player::gethp(){
    return hp;
}
void Player::newhp(int dmgTaken){
    hp = hp - dmgTaken;
}
void Player::restorehp(){
    hp = maxhp;
}

//mana functions
int Player::getmp(){
    return mp;
}
void Player::newmp(int manaUsed){
    mp = mp - manaUsed;
}
void Player::restoremp(){
    mp = maxmp;
}

//armor functions
int Player::getap(){
    return ap;
}
void Player::removeap(){
    ap = ap - 1;
}
void Player::restoreap(){
    ap = maxap;
}

//attack functions
void Player::setAttack(string attackFile){
}
void Player::readAttacks(){

}
int Player::performAttack(int attackNum){
    
} //this will compute the damage dealt as well as the new base damage