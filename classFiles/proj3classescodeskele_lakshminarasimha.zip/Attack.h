#ifndef ATTACK_H
#define ATTACK_H
#include <iostream>
using namespace std;
class Attack{
    private:
        string atkName;
        int baseDmg;
        bool atkType; //Physical is True, Magical is False
        double dmgInc;
        int manaCost; //0 for all physical attacks
    
    public:
        Attack();
        Attack(string name, int dmg, string type, double inc, int mCost);

        //attack name
        void setAtkName(string name);
        string getAtkName();

        //base damage
        void setBaseDmg(int dmg);
        int getBaseDmg();

        //attack type
        void setAtkType(string type);
        bool getAtkType();

        //damage increment per usage of move. the new base damage will still be an int
        void setDmgInc(double inc);
        double getDmgInc();

        //mana cost
        void setManaCost(int mCost);
        int getManaCost();

};
#endif